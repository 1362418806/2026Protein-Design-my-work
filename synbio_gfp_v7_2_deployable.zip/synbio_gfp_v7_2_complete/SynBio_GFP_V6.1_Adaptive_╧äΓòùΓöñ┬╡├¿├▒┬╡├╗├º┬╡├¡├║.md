# SynBio GFP V6.1 Adaptive 维护文档

## 1. 当前任务与硬约束

当前项目是 2026 SynBio sfGFP 蛋白设计挑战。目标是在最多 6 条序列中获得高初始亮度与 72°C 10 分钟热处理后的高残余荧光。官方评分可理解为最大化 `F_final / F_initialWT`，但若 `F_initial < 0.3 × sfGFP`，该序列直接记 0 分。因此所有算法必须优先保证 sfGFP-like folding、发色团成熟、初始亮度安全、β-barrel 结构保真，再提升热稳定性和抗聚集性。

## 2. 为什么不回退到 V5

V4/V5/V5.1 已经完成工程闭环：生成候选、导出 Top-200、结构预测、`structure_metrics.csv`、ProteinMPNN score-only、final reranking 和 submission。但 V5/V5.1 的结构与 ProteinMPNN 只影响已进入 Top-200 的候选，不会改变候选生成空间、mutation policy、source_branch 权重或 motif-level 搜索策略。因此 V4/V5 report 近乎一致是合理现象，根因是 post-hoc reranking 不足以改变搜索分布。

## 3. V6 的价值与不足

V6 的价值是把 pipeline 从 `generate → score → structure/ProteinMPNN → rerank` 推进为 closed-loop generation：历史反馈进入 branch / mutation / position policy，再重新生成候选。V6 已经能完整跑通 production，并输出非空合法 Top-6。它相比 V4/V5 更可追溯、结构证据更真实、低亮度风险更低、平均多样性更高。

当前 V6 不足是：feedback_* 分支未进入 final Top-6；Top-6 仍偏 conservative / tgp_surface / balanced；亮度模型不确定性升高；Seq_5 一类高 mutation_count、高 low_brightness_risk 候选存在风险；final portfolio 的硬约束仍需加强。

## 4. V6.1 Adaptive 的定义

V6.1 Adaptive = V6 closed-loop generation + GPU-profile adaptive runtime + automatic PDB registry / reuse-first + V5.1 brightness safety teacher + physical thermal proxy + feedback survival learning + strict final portfolio selection。

它不是 3090 专版，而是支持 `GPU_PROFILE=auto / rtx3090_24g / rtx5090 / a800` 的自适应版本。如果算法需求较高，可以继续使用 5090 或 A800。

## 5. 核心工程改进

### 5.1 数据路径

默认读取 `/input0/2026Protein Design`，并 fallback 到 `/hyperai/input/input0/2026Protein Design` 与 `/root/2026Protein Design`。

### 5.2 PDB 自动复用

新增 `tools/resolve_structures_v61.py`。它自动扫描历史 outputs，建立 `pdb_registry.csv`，按 `sequence_sha1 + sequence_length` 匹配当前候选，精确序列匹配时复用 PDB，缺失时才预测。PDB 可复用，但 structure metrics 每轮必须重算。

### 5.3 结构策略

支持 `reuse-only`、`reuse-first`、`predict-missing`、`metrics-only`。正式提交不应依赖 `metrics-only`。

## 6. 核心算法改进

### 6.1 亮度安全 teacher

V6.1 支持通过 `--brightness-teacher-csv` 接入 V5.1/V6 历史 ranked CSV 的 exact-sequence brightness safety teacher。默认在有完全相同 sequence 时融合 teacher 的 `brightness_lcb` 与 `low_brightness_risk`，避免 V6 单模型不确定性过高导致风险候选进入 final。

### 6.2 物理化 thermal proxy

新增 `thermal_proxy_v61`，拆成 structure RMSD、surface charge、hydrophobic patch penalty、salt bridge potential、aggregation safety、loop rigidity、ProteinMPNN compatibility 和 foldability proxy。TGP 先验被理解为结构引导表面工程，而不是无脑酸性替换。

### 6.3 feedback 生存率学习

新增 `v61_feedback_survival_by_branch.csv` 与 `v61_feedback_survival_report.md`，统计每个 source_branch 的 basic gate、structure pass、ProteinMPNN 有效率、final eligible、low-risk survival。后续应基于这些数据调整 branch weight、mutation log-odds、position log-odds、motif whitelist/blacklist。

### 6.4 Final Top-6 硬约束

最终选择不再是简单 Top-6，而是硬约束 portfolio：

- `structure_pass=True`
- 不命中 Exclusion_List
- `low_brightness_risk <= 0.20`
- 正常候选 `mutation_count <= 5`
- 最多一条探索候选允许 `mutation_count = 6`
- `min_pairwise_hamming >= 5`
- `max_per_source_branch <= 2`
- `max_shared_mutation_sites <= 3`

最终 6 条应尽量覆盖 conservative high-brightness、thermal surface、loop rigidity、feedback repaired、ProteinMPNN-compatible surface redesign、low-correlated explorer。

## 7. 推荐运行方式

```bash
cd /hyperai/home/synbio_gfp_v61_adaptive
source deploy/env_v61.sh
TEAM_NAME=YourTeamName DATA_DIR="/input0/2026Protein Design" GPU_PROFILE=auto STRUCTURE_POLICY=reuse-first RUN_PROTEINMPNN=1 bash deploy/run_v61_all.sh
```

## 8. 下一步维护重点

1. 先确认 `valid_structure_scores > 0`、`valid_proteinmpnn_scores > 0`、`final_selected = 6`。
2. 检查 `v61_feedback_survival_by_branch.csv`，定位 feedback_* 分支死在哪一步。
3. 若 feedback 分支安全但未入选，调高 Top-200 或 final mechanism quota。
4. 若 low-risk 候选不足，优先加强 brightness_lcb / low_risk 权重，不要先扩大突变数。
5. 若热稳定 proxy 不足，优先改 surface patch / aggregation / salt bridge 评分，不要直接切换 AF3/OpenComplex2。

## 9. 代码修改原则

后续维护必须严格按需修改。只改明确指定模块；未指定的问题只给建议，不擅自重构。所有改动过的核心逻辑需要英文注释，便于后续交接和复现。
